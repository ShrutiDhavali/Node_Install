package com.mtfi.issuer.admin.beans;

public class ActiveTurbosDTO {
   String  isin;
    String currentStrikeLevel;
    String  originalStrikeLevel;
    String    direction;
    String    issuedDate;

    public String getIsin() {
        return isin;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    public String getCurrentStrikeLevel() {
        return currentStrikeLevel;
    }

    public void setCurrentStrikeLevel(String currentStrikeLevel) {
        this.currentStrikeLevel = currentStrikeLevel;
    }

    public String getOriginalStrikeLevel() {
        return originalStrikeLevel;
    }

    public void setOriginalStrikeLevel(String originalStrikeLevel) {
        this.originalStrikeLevel = originalStrikeLevel;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getIssuedDate() {
        return issuedDate;
    }

    public void setIssuedDate(String issuedDate) {
        this.issuedDate = issuedDate;
    }
}
