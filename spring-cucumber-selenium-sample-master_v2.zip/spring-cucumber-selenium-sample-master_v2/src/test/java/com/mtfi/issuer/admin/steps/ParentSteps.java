package com.mtfi.issuer.admin.steps;

import com.mtfi.issuer.admin.spring.CucumberContext;
import com.mtfi.issuer.admin.utility.PropertiesFileReader;
import cucumber.api.Scenario;
import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.testng.asserts.SoftAssert;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

@ContextConfiguration(classes={CucumberContext.class})
public class ParentSteps  {

	@Autowired
	protected WebDriver webdriver;
	
	@Autowired
	protected WebDriverWait wait;
	
	@Autowired
	protected boolean screenshotOnFailure;

	@Autowired
	@Qualifier("screenshotDestinationFolder")
	protected String screenshotDestinationFolder;

	@Qualifier("Application_Url")
	@Autowired
	protected String Application_Url;

	@Autowired
	@Qualifier("userName")
	protected String userName;

	@Autowired
	@Qualifier("passWord")
	protected String passWord;

	@Qualifier("IGIP_Gateway_API")
	@Autowired
	protected  String IGIP_Gateway_API;

	@Qualifier("securityTokenURL")

	@Autowired
	protected String securityTokenURL;


	public void waitforElementToLoad(){
		webdriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@AfterClass
	public  void closedriver(){
		webdriver.close();
	}

	@After
	public void afterScenario(Scenario scenario) throws IOException, InterruptedException {
		if (scenario.isFailed()) {
			if (screenshotOnFailure) {
				Date now = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMDDHHmmss");
				String timestamp = sdf.format(now);

				File srcFile = ((TakesScreenshot) webdriver).getScreenshotAs(OutputType.FILE);
				File destFile = new File(screenshotDestinationFolder
						+ timestamp + "_"
						+ scenario.getName().replaceAll(" ", "_") + ".png");
				FileUtils.moveFile(srcFile, destFile);
				System.out.println("Screenshot taken: " + destFile.getAbsolutePath());

			}
		}
	}
}
