
package com.mtfi.issuer.admin.spring;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
public class PropertiesContext {

	@Value("${selenium.screenshotOnFailure}")
	private String screenshotOnFailure;

	@Bean("screenshotOnFailure")
	public boolean takeScreenshotOnFailure() {
		return Boolean.parseBoolean(screenshotOnFailure);
	}

	@Value("${selenium.screenshotDestinationFolder}")
	private String screenshotDestinationFolder;

	@Bean("screenshotDestinationFolder")
	public String getScreenshotDestinationFolder() {
		return screenshotDestinationFolder;
	}

	@Value("${selenium.webbrowser}")
	private String webbrowser;

	@Bean("webbrowser")
	public String getWebbrowser() {
		return webbrowser;
	}

	@Value("${selenium.application.url}")
	private String Application_Url;

	@Bean("Application_Url")
	public String getApplication_Url() {
		return Application_Url;
	}
	@Value("${selenium.igip.gateway.api}")
	private String IGIP_Gateway_API;

	@Bean("IGIP_Gateway_API")
	public String getIGIP_Gateway_API(){
		return IGIP_Gateway_API;
	}

	@Value("${selenium.username}")
	private String userName;

	@Bean("userName")
	public String getUserName(){
		return userName;
	}

	@Value("${selenium.password}")
	private  String passWord;

	@Bean ("passWord")
	public String getPassWord(){
		return passWord;
	}

	@Value("${security.token.url}")
	private String securityTokenURL;

	@Bean("securityTokenURL")
	public String getSecurityTokenURL(){
		return securityTokenURL;
	}
}

