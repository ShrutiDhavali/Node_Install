package com.mtfi.issuer.admin;

import com.cucumber.listener.Reporter;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

import java.io.File;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"src/test/java/com/mtfi/issuer/admin/features"},
        tags = {"@1"},
		plugin = { "com.cucumber.listener.ExtentCucumberFormatter:target/report.html"})
public class CucumberRunnerTest {


    @AfterClass
    public static void setup() {
        Reporter.loadXMLConfig(new File("config/report.xml"));
        Reporter.setSystemInfo("Application", "MTFI_Issuer");
        Reporter.setSystemInfo("user", System.getProperty("user.name"));
        Reporter.setSystemInfo("os", System.getProperty("os.name"));
    }

}
