package com.mtfi.issuer.admin.utility;

import org.springframework.stereotype.Repository;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertiesFileReader {
	public Properties obj = new Properties();
	public PropertiesFileReader() {
		try {
			
			FileInputStream objfile;
			objfile = new FileInputStream("src/main/resources/application.properties");
			obj.load(objfile);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public String getChromePath() {
		return obj.getProperty("Chrome_Path");	
	}
	
	public String getAppLocationUrl() {
		return obj.getProperty("Application_Url");	
	}
}
