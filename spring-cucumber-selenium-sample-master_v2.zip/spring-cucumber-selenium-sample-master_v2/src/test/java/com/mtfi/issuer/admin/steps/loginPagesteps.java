package com.mtfi.issuer.admin.steps;

import com.mtfi.issuer.admin.pageobjects.logIn.loginPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;

public class loginPagesteps extends  ParentSteps {

    @Autowired
    com.mtfi.issuer.admin.pageobjects.logIn.loginPage loginPage;

    @Given("^Open MTFI Issuer$")
    public void open_MTFI_Issuer() throws Throwable {
        webdriver.get(Application_Url);
        webdriver.manage().window().maximize();
        Thread.sleep(5000);
    }

    @When("^Login to MTFI$")
    public void login_to_MTFI() throws Throwable {
        loginPage.loginToMTFIIssuer();
        Thread.sleep(5000);
    }

    @Then("^logout$")
    public void logout() {
        loginPage.logOut();
    }
}
