package com.mtfi.issuer.admin.utility;

public class Constants {

    public static final String USERNAMETEXTBOX="ember11";
    public static final String PASSWORDTEXTBOX="ember12";
    public static final String LOGINBUTTON="//div[@class=\"form-actions\"]/button";
    public static final String LOGOUTBUTTON="//div[@class=\"fmt-toolbar__items\"]/div[4]/button[contains(text(),'Logout')]";
    public static final String KOCOUNT="//span[@class=\"knockout-count\"]";
    public static final String ISIN= "//div[@class=\"col-md-12\"][1]/div/div/div[3]/div/div/div[3]/table/tbody/tr[1]/td[3]";
    public static final String STRIKE_LEVEL = "//div[@class=\"col-md-12\"][1]/div/div/div[3]/div/div/div[3]/table/tbody/tr[1]/td[4]";
    public static final String  KO_TICK = "//div[@class=\"col-md-12\"][1]/div/div/div[3]/div/div/div[3]/table/tbody/tr[1]/td[5]";
    public static final String PREVIOUS_TICK="//div[@class=\"col-md-12\"][1]/div/div/div[3]/div/div/div[3]/table/tbody/tr[1]/td[6]";
    public static final String CHECK_BOX="//div[@class=\"col-md-12\"][1]/div/div/div[3]/div/div/div[3]/table/tbody/tr[1]/td[1]/div/div/span";
    public static final String APPROVE_BUTTON="//div[@class=\"actions\"]/button[1]";
    public static final String MODAL_APPROVE_BUTTON="//div[@class=\"modal-footer\"]/button[1]";
    public static final String MODAL_CANCEL_BUTTON="//div[@class=\"modal-footer\"]/button[2]";
}
