package com.mtfi.issuer.admin.steps;

import com.mtfi.issuer.admin.pageobjects.Alert.AlertPage;
import com.mtfi.issuer.admin.pageobjects.logIn.loginPage;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;

public class AlertSteps extends ParentSteps{

@Autowired
AlertPage alertPage;

	@Then("^For \"([^\"]*)\" page Verify the \"([^\"]*)\" count\\.$")
	public void for_page_Verify_the_count(String alert, String koAlert) throws Throwable {
		alertPage.checkAlertDetails(alert,koAlert);
		Thread.sleep(10000);
	}

	@And("^in  \"([^\"]*)\" page select any warrant in \"([^\"]*)\" section$")
	public void inPageSelectAnyWarrantInSection(String alert, String koAlert) throws Throwable {
		alertPage.clickOnWarrant();
	}

	@And("^click on Aprrove button$")
	public void clickOnAprroveButton() throws Throwable {
		alertPage.clickOnApproveButton();
	}
	@And("^again click on Approve button in modal$")
	public void againClickOnApproveButtonInModal() throws  Throwable{
		alertPage.clickOnApproveInModal();
	}

	@Then("^in \"([^\"]*)\" page  Warrant is not available in the \"([^\"]*)\" section$")
	public void inPageWarrantIsNotAvailableInTheSection(String alert, String koAlert) throws Throwable {
		alertPage.checkWarrantAfterApproval(alert,koAlert);
		webdriver.close();
	}

	@And("^click on Cancel button in the modal$")
	public void clickOnCancelButtonInTheModal() throws Throwable {
		alertPage.clickOnCancelButton();
	}

	@Then("^in \"([^\"]*)\" page Warrant is available in the \"([^\"]*)\" section$")
	public void inPageWarrantIsAvailableInTheSection(String alert, String koAlert) throws Throwable {
		alertPage.checkWarrantAfterCancelInModal(alert,koAlert);
	}

	@And("^in  \"([^\"]*)\" page select (\\d+) warrants in KO Alerts section\\.$")
	public void inPageSelectWarrantsInKOAlertsSection(String alert, int noOfWarrants) throws Throwable {
		alertPage.selectMultipleWarrants(alert,noOfWarrants);
	}

	@Then("^in \"([^\"]*)\" page selected Warrants are available in the KO Alerts section$")
	public void inPageSelectedWarrantsAreAvailableInTheKOAlertsSection(String alertPage) throws Throwable {
		System.out.println("Yes");
	}

	@Given("^The test data from \"([^\"]*)\" API for \"([^\"]*)\"$")
	public void theTestDataFromAPIFor(String activeTurbo, String underlyingSymbol) throws Throwable {
		alertPage.getTheActiveTurbos(activeTurbo,underlyingSymbol);
    }
}
