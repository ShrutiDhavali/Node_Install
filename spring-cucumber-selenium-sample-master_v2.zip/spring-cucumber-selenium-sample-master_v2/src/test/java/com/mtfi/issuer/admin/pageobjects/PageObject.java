package com.mtfi.issuer.admin.pageobjects;

import com.mtfi.issuer.admin.spring.CucumberContext;
import com.mtfi.issuer.admin.steps.ParentSteps;
import com.mtfi.issuer.admin.utility.PropertiesFileReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;

@ComponentScan("com.mtfi.issuer.admin")
public class PageObject extends ParentSteps {
	public WebDriver webdriver;
	public PageObject(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.webdriver = driver;
	}
}
