package com.mtfi.issuer.admin.steps;

import com.mtfi.issuer.admin.pageobjects.Alert.AlertPage;
import cucumber.api.java.en.Given;
import org.springframework.beans.factory.annotation.Autowired;

public class ActiveTurboSteps {

    @Autowired
    AlertPage alertPage;

    @Given("^Prepare test data from \"([^\"]*)\" API for \"([^\"]*)\"$")
    public void prepareTestDataFromAPIFor(String activeTurbo, String underlyingSymbol) throws Throwable {
        alertPage.getTheActiveTurbos(activeTurbo,underlyingSymbol);
    }

}
