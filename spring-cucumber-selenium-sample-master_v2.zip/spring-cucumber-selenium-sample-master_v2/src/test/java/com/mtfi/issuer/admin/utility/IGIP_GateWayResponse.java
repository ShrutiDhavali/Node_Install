package com.mtfi.issuer.admin.utility;

import com.mtfi.issuer.admin.pageobjects.securitytoken.TokenGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@Component
public class IGIP_GateWayResponse extends PropertiesFileReader{

	@Autowired
	TokenGenerator tokenGenerator;

	private String  activeTurboAPI= null;

	public String getKOResponse(String gatwayURL, String securityTokenURL) throws Exception {

			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			List<HttpMessageConverter<?>> messageConverters= new ArrayList<>();
			messageConverters.add(new StringHttpMessageConverter());
			restTemplate.setMessageConverters(messageConverters);
			//Disable SSL Certificate
			new DisableSSL().disablessl();

			headers.set("X-SECURITY-TOKEN",tokenGenerator.getToken(securityTokenURL));
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity  request = new HttpEntity(headers);
			ResponseEntity<String> responseEntityString =  restTemplate.exchange(gatwayURL, HttpMethod.GET,request, String.class);
			return responseEntityString.getBody().toString();

	}

	public String getActiveTurbos(String activeTurboURL, String securityTokenURL,String underlyingSymbol) throws Exception {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		List<HttpMessageConverter<?>> messageConverters= new ArrayList<>();
		messageConverters.add(new StringHttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		//Disable SSL Certificate
		new DisableSSL().disablessl();
		headers.set("X-SECURITY-TOKEN",tokenGenerator.getToken(securityTokenURL));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity  request = new HttpEntity(headers);

		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(activeTurboURL)
				.queryParam("underlyingSymbol",underlyingSymbol);
		ResponseEntity<String> responseEntityString =  restTemplate.exchange(uriBuilder.toUriString(), HttpMethod.GET,request, String.class);
		return responseEntityString.getBody().toString();

	}
	public String getHistoricDividends(String historicDividendsURL, String securityTokenURL,String dateTime) throws Exception {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		List<HttpMessageConverter<?>> messageConverters= new ArrayList<>();
		messageConverters.add(new StringHttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		//Disable SSL Certificate
		new DisableSSL().disablessl();
		headers.set("X-SECURITY-TOKEN",tokenGenerator.getToken(securityTokenURL));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity request = new HttpEntity<>(headers);
		String[] arrSplit = dateTime.split("- ");
		String startDateTime= getDateTime(arrSplit[0]);
		String endDateTime= getDateTime( arrSplit[1] );
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(historicDividendsURL).queryParam("endDateTime", endDateTime).queryParam( "startDateTime",startDateTime);
		UriComponents uriComponents = uriBuilder.build(true);
		URI uri = uriComponents.toUri();
		ResponseEntity<String> responseEntityString =  restTemplate.exchange(uri, HttpMethod.GET, request, String.class);
		log.info( responseEntityString.getBody().toString() );
		return responseEntityString.getBody().toString();
	}

	public String getDateTime(String dateTime){
		DateFormat inputformat = new SimpleDateFormat("dd/MMM/yyyy HH:mm");
		DateFormat outputformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS+00:00");
		Date inputdate=null;
		String formattedDate=null;
		try{
			inputdate=inputformat.parse( dateTime );
			formattedDate=outputformat.format( inputdate ).replaceAll( ":","%3A" ).replaceAll( "\\+","%2B" );
			log.info( "formattedDate:" + formattedDate );
		}catch(ParseException pe){
			log.info( "Date Parsing not done" + pe );
		}
		return formattedDate;
	}

	public String getDividendCorrectionDetails(String dividendCorrectionURL, String securityTokenURL, String underlyingSymbol, String yesterday) throws  Exception{

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		List<HttpMessageConverter<?>> messageConverters= new ArrayList<>();
		messageConverters.add(new StringHttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		//Disable SSL Certificate
		new DisableSSL().disablessl();
		headers.set("X-SECURITY-TOKEN",tokenGenerator.getToken(securityTokenURL));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity request = new HttpEntity<>(headers);
		String yesterdayDate= getDateTime(yesterday + " 00:00");
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(dividendCorrectionURL).queryParam("appliedDate", yesterdayDate).queryParam( "underlyingSymbol", underlyingSymbol );
		UriComponents uriComponents = uriBuilder.build(true);
		URI uri = uriComponents.toUri();
		log.info( "uri" + uri );
		ResponseEntity<String> responseEntityString =  restTemplate.exchange(uri, HttpMethod.GET, request, String.class);
		log.info( responseEntityString.getBody().toString() );
		return responseEntityString.getBody().toString();
	}
}
