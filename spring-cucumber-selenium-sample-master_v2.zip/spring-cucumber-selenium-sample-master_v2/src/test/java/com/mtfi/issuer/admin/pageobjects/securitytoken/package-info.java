
@XmlSchema(
        namespace="http://reference.igindex.co.uk/schema/v1" ,
        elementFormDefault= XmlNsForm.QUALIFIED)
package com.mtfi.issuer.admin.pageobjects.securitytoken;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;
