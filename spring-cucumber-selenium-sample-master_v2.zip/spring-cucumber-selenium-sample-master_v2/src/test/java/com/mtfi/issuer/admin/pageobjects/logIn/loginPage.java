package com.mtfi.issuer.admin.pageobjects.logIn;

import com.cucumber.listener.Reporter;
import com.mtfi.issuer.admin.pageobjects.PageObject;
import com.mtfi.issuer.admin.utility.Constants;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import static org.junit.Assert.assertTrue;

@Slf4j
@Component
@ComponentScan("com.mtfi.issuer.admin")
public class loginPage extends PageObject {

    @FindBy(how = How.ID, using = Constants.USERNAMETEXTBOX)
    public WebElement UserNameTextbox;

    @FindBy(how = How.ID, using = Constants.PASSWORDTEXTBOX)
    public WebElement PassWordTextBox;

    @FindBy(how = How.XPATH, using = Constants.LOGINBUTTON)
    public WebElement LoginButton;

    @FindBy(how = How.XPATH, using = Constants.LOGOUTBUTTON)
    public WebElement logOutButton;

    public loginPage(WebDriver driver) {
        super(driver);
    }

    public void loginToMTFIIssuer() throws Exception {
        UserNameTextbox.sendKeys(userName);
        PassWordTextBox.sendKeys(passWord);
        LoginButton.click();
        Thread.sleep(10000);
        try {
            if (webdriver.findElement(By.xpath(Constants.LOGOUTBUTTON)).isDisplayed()) {
                Reporter.addStepLog("Log in Passed");
                assertTrue(true);
            } else {
                Reporter.addStepLog("Log in Failed");
                assertTrue(false);
            }
        }catch(AssertionError  e){
            log.info("AssertionError :" + e);
        }
    }

    public void logOut(){
        logOutButton.click();
    }
}
