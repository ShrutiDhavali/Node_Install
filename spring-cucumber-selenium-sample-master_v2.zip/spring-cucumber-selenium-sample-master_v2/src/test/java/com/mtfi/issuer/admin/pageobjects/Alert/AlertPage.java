package com.mtfi.issuer.admin.pageobjects.Alert;

import java.util.List;

import com.cucumber.listener.Reporter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mtfi.issuer.admin.beans.ActiveTurbosDTO;
import com.mtfi.issuer.admin.beans.KnockoutAlertDTO;
import com.mtfi.issuer.admin.pageobjects.PageObject;
import com.mtfi.issuer.admin.utility.Constants;
import com.mtfi.issuer.admin.utility.IGIP_GateWayResponse;
import com.mtfi.issuer.admin.utility.IssuerValues;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.testng.asserts.SoftAssert;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


@Slf4j
@Component
@ComponentScan("com.mtfi.issuer.admin")
public class AlertPage extends PageObject {

    @Autowired
    IGIP_GateWayResponse igipGateWayResponse;

    @FindBy(how=How.XPATH, using = Constants.KOCOUNT)
    public WebElement KOCount;

    @FindBy(how = How.XPATH, using = Constants.ISIN)
    public WebElement isin;

    @FindBy(how = How.XPATH, using = Constants.STRIKE_LEVEL)
    public WebElement strickeLevel;

    @FindBy(how = How.XPATH, using = Constants.KO_TICK)
    public WebElement koTick;

    @FindBy(how = How.XPATH, using = Constants.PREVIOUS_TICK)
    public WebElement previousTick;

    @FindBy(how = How.XPATH, using = Constants.CHECK_BOX)
    public WebElement checkBox;

    @FindBy(how = How.XPATH, using = Constants.APPROVE_BUTTON)
    public WebElement approveButton;

    @FindBy(how = How.XPATH, using = Constants.MODAL_APPROVE_BUTTON)
    public WebElement modalApproveButton;

    @FindBy(how = How.XPATH, using = Constants.MODAL_CANCEL_BUTTON)
    public WebElement modalCancelButton;

    private String  checkISIN=null;

    SoftAssert softAssert= new SoftAssert();

   private List<KnockoutAlertDTO> knockoutAlerts;
   public List<ActiveTurbosDTO> activeTurbos;
   public List<ActiveTurbosDTO> preKnockOutTurbos;
   private  int noOfWarrants;


    public AlertPage(WebDriver driver) {
        super(driver);
    }

    public void getTheActiveTurbos(String activeTurbo,String underlyingSymbol) throws Exception {
        activeTurbos=null;
        for (IssuerValues iv : IssuerValues.values()) {
            if (iv.name().equalsIgnoreCase(activeTurbo)) {
                String activeTurboResponse= igipGateWayResponse.getActiveTurbos(IGIP_Gateway_API + iv.getUrl1(), securityTokenURL,underlyingSymbol);
                JSONObject jsonObject = new JSONObject(activeTurboResponse);
                JSONArray jsonArray = jsonObject.getJSONArray("mtf-issuer/underlying/active-turbo");
                ObjectMapper mapper = new ObjectMapper();
                activeTurbos =  mapper.readValue(jsonArray.toString(), mapper.getTypeFactory().constructCollectionType(List.class, ActiveTurbosDTO.class));
                log.info("Turbos:" + activeTurbos.toString());
            }
        }
    }


    public List<KnockoutAlertDTO> getKODetails( String alertPage) throws Exception {
         knockoutAlerts = null;
        for (IssuerValues iv : IssuerValues.values()) {
            if (iv.name().equalsIgnoreCase(alertPage)) {
                String KOResponse = igipGateWayResponse.getKOResponse(IGIP_Gateway_API + iv.getUrl1(), securityTokenURL);
                JSONObject jsonObject = new JSONObject(KOResponse);
                JSONArray jsonArray = jsonObject.getJSONArray("mtf-issuer/alerts/knockout-alerts");
                ObjectMapper mapper = new ObjectMapper();
                knockoutAlerts=  mapper.readValue(jsonArray.toString(), mapper.getTypeFactory().constructCollectionType(List.class, KnockoutAlertDTO.class));
            }
        }
        return  knockoutAlerts;
    }

    public void checkAlertDetails(String alertPage, String koAlert) throws Exception {
        knockoutAlerts=getKODetails(alertPage);
        try {
            softAssert.assertEquals(Integer.parseInt(KOCount.getText()), knockoutAlerts.size() + 1);
            softAssert.assertEquals(isin.getText(), knockoutAlerts.get(0).getIsin());
            softAssert.assertEquals(strickeLevel.getText(), knockoutAlerts.get(0).getStrikeLevel());
            softAssert.assertEquals(koTick.getText(), knockoutAlerts.get(0).getKnockedOutTickPrice());
            softAssert.assertEquals(previousTick.getText(), knockoutAlerts.get(0).getPreviousTickPrice());
        }catch (AssertionError e){
            log.info("AssertionError :" + e);
        }

    }

    public void clickOnWarrant(){
        checkISIN = isin.getText();
        checkBox.click();
    }

    public void clickOnApproveButton() throws InterruptedException {
        approveButton.click();
        Thread.sleep(10000);
    }

    public void clickOnApproveInModal(){
        modalApproveButton.click();
    }
    public void checkWarrantAfterApproval(String alertPage, String koAlert) throws Exception {
        knockoutAlerts=getKODetails(alertPage);
        try {
            if (!knockoutAlerts.get(0).getIsin().contains(checkISIN)) {
                Reporter.addStepLog("ISIN not in the KO List, Hence Manual KO is Successful");
                softAssert.assertTrue(true);
            } else {
                Reporter.addStepLog("ISIN is th KO list, Hence Manual KO is Unsuccessful");
                softAssert.assertTrue(false);
            }
        }catch(AssertionError  e){
            log.info("AssertionError :" + e);
        }
    }
    public void clickOnCancelButton(){
        modalCancelButton.click();
    }
    public void checkWarrantAfterCancelInModal(String alertPage,String koAlert) throws Exception {
        knockoutAlerts=getKODetails(alertPage);
        try {
            if (knockoutAlerts.get(0).getIsin().contains(checkISIN)) {
                Reporter.addStepLog("ISIN is in the KO List, Hence cancel of Manual KO is Successful");
                softAssert.assertTrue(true);
            } else {
                Reporter.addStepLog("ISIN not in the KO list, Hence cancel of Manual KO is Unsuccessful");
                softAssert.assertTrue(false);
            }
        }catch(AssertionError  e){
            log.info("AssertionError :" + e);
        }
    }
    public void selectMultipleWarrants(String alertPage, int noOfWarrants){
        this.noOfWarrants=noOfWarrants;
        for (int i=1;i<=noOfWarrants; i++){
         webdriver.findElement(By.xpath("//div[@class=\"col-md-12\"][1]/div/div/div[3]/div/div/div[3]/table/tbody/tr[" +i + "]/td[1]/div/div/span")).click();
        }
    }


}
