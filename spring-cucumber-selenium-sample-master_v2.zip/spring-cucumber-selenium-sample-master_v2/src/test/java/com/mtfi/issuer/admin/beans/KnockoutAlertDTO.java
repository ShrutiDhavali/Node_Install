package com.mtfi.issuer.admin.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


public class KnockoutAlertDTO {

    String isin ;
    String  legalName;
    String  warrantName;
    String  direction;
    String  strikeLevel;
    String  knockedOutTickPrice;
    String  knockedOutTickPriceTime;
    String  previousTickPrice;
    String  previousTickPRiceTime;
    String  ricCode;
    String  marketName;
    String  status;

 public String getIsin() {
  return isin;
 }

 public void setIsin(String isin) {
  this.isin = isin;
 }

 public String getLegalName() {
  return legalName;
 }

 public void setLegalName(String legalName) {
  this.legalName = legalName;
 }

 public String getWarrantName() {
  return warrantName;
 }

 public void setWarrantName(String warrantName) {
  this.warrantName = warrantName;
 }

 public String getDirection() {
  return direction;
 }

 public void setDirection(String direction) {
  this.direction = direction;
 }

 public String getStrikeLevel() {
  return strikeLevel;
 }

 public void setStrikeLevel(String strikeLevel) {
  this.strikeLevel = strikeLevel;
 }

 public String getKnockedOutTickPrice() {
  return knockedOutTickPrice;
 }

 public void setKnockedOutTickPrice(String knockedOutTickPrice) {
  this.knockedOutTickPrice = knockedOutTickPrice;
 }

 public String getKnockedOutTickPriceTime() {
  return knockedOutTickPriceTime;
 }

 public void setKnockedOutTickPriceTime(String knockedOutTickPriceTime) {
  this.knockedOutTickPriceTime = knockedOutTickPriceTime;
 }

 public String getPreviousTickPrice() {
  return previousTickPrice;
 }

 public void setPreviousTickPrice(String previousTickPrice) {
  this.previousTickPrice = previousTickPrice;
 }

 public String getPreviousTickPRiceTime() {
  return previousTickPRiceTime;
 }

 public void setPreviousTickPRiceTime(String previousTickPRiceTime) {
  this.previousTickPRiceTime = previousTickPRiceTime;
 }

 public String getRicCode() {
  return ricCode;
 }

 public void setRicCode(String ricCode) {
  this.ricCode = ricCode;
 }

 public String getMarketName() {
  return marketName;
 }

 public void setMarketName(String marketName) {
  this.marketName = marketName;
 }

 public String getStatus() {
  return status;
 }

 public void setStatus(String status) {
  this.status = status;
 }
}
