package com.mtfi.issuer.admin.steps;

import com.mtfi.issuer.admin.pageobjects.securitytoken.TokenGenerator;
import cucumber.api.java.en.When;

public class SecurityTokenSteps {
    com.mtfi.issuer.admin.pageobjects.securitytoken.TokenGenerator TokenGenerator = new TokenGenerator();

    @When("^the client calls /token$")
    public void theClientCallsToken() throws Exception {
        TokenGenerator.getToken("https://ip1.test.iggroup.local/singlesignon/token");
    }
}
