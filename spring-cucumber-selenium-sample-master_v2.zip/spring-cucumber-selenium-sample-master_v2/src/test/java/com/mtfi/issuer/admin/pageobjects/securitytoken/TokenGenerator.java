package com.mtfi.issuer.admin.pageobjects.securitytoken;

import com.mtfi.issuer.admin.steps.ParentSteps;
import com.mtfi.issuer.admin.utility.DisableSSL;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;
import java.net.URI;
import java.util.*;

import static javax.xml.bind.JAXBContext.newInstance;
@Slf4j
@Component
@ComponentScan("com.mtfi.issuer.admin")
public class TokenGenerator extends ParentSteps {

    public String  getToken(String url) throws Exception {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        List<HttpMessageConverter<?>> messageConverters= new ArrayList<>();

        URI STurl = new URI (url.trim().replaceAll(" ","%20"));

        String xmldata= "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                "<UserCredentials xmlns=\"http://reference.igindex.co.uk/schema/v1\">\n" +
                "<UserName>" +userName +"</UserName>\n" +
                "<Password>" +passWord + "</Password>\n" +
                "</UserCredentials>";

        new DisableSSL().disablessl();
        messageConverters.add(new StringHttpMessageConverter());
        restTemplate.setMessageConverters(messageConverters);
        headers.setContentType(MediaType.TEXT_XML);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_XML));
        HttpEntity<String> request = new HttpEntity<String>(xmldata, headers);
        String  tokenxml= restTemplate.postForObject(STurl,request,String.class);
        log.info("Token:"+ convertXMLTokenToTokenObj(tokenxml) );
        return convertXMLTokenToTokenObj(tokenxml);

    }

    public String convertXMLTokenToTokenObj(String tokenxml){
        JAXBContext jaxbContext;
        SecureToken securityToken = null;
        try
        {
            jaxbContext = newInstance(SecureToken.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            securityToken = (SecureToken) jaxbUnmarshaller.unmarshal(new StringReader(tokenxml));
        }
        catch (JAXBException e)
        {
            e.printStackTrace();
        }
        return securityToken.getToken();
    }

}
