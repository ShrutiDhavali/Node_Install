package com.mtfi.issuer.admin.utility;

public enum IssuerValues {
	
	ALERT( "alerts/knockout-alerts", "alerts/status-alerts"),
	ACTIVE_TURBO("underlying/active-turbos", "");

	public String url1;
	public String url2;

	public String getUrl1() {
		return url1;
	}
	public String getUrl2() {
		return url1;
	}

	IssuerValues(String url1, String url2) {
		this.url1=url1;
		this.url2=url2;
	}
	
}
